package exception;

public class ShopException extends Exception{
	public ShopException(String message) {
		super(message);
	}
}